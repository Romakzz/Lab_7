#include <avr/io.h>
#include <util/delay.h>

char A[10] = {'0','b','0','1','0','0','0','0','0','1'};
char Y[10];


void right(void){
	PORTC = 0b00000011;
	_delay_ms(200);
	PORTC = 0b00000000;
	_delay_ms(200);
	
	PORTC =  0b00000011;
	_delay_ms(200);
	PORTC =  0b00000000;
	_delay_ms(200);
	
	PORTC =  0b00000011;
	_delay_ms(200);
	PORTC =  0b00000000;
	_delay_ms(200);
}


void wrong(void){
			PORTC = 0b00000011;
			_delay_ms(500);
			PORTC = 0b00000000;
			_delay_ms(500);
	
			PORTC = 0b00000011;
			_delay_ms(500);
			PORTC = 0b00000000;
			_delay_ms(500);
}

int main(void)
{
	

	DDRA = 0b00000000;
	DDRC = 0b00000011;
	PORTC = 0b0000000;
	
	int x=2,c=0;
    
	while (1) 
    {	
		Y[0] = '0';
		Y[1] = 'b';
		if (!(PINA & 0b00000001))
		{
			Y[11-x] = '1';
			x = x + 1;
			c = c + 1;
			_delay_ms(200);
		}
		if (!(PINA & 0b00000010))
		{
			Y[11-x] = '0';
			x = x + 1;
			c = c + 1;
			_delay_ms(200);
		}
		if (!(PINA & 0b00000100))
		{
			x = x - 1;
			c = c - 1;	
			_delay_ms(200);
		}
		_delay_ms(200);
		
		if(c==8){
			
			int z = 0;
			
			for(int i = 0; i<10; i++){
				if(Y[i] == A[i]){
				z = z + 1;
				}
			}
	
			if(z == 10){
				right();
			}else{
				wrong();
			}
			
			x=2;
			c=0;
			_delay_ms(200);
    }
}

}